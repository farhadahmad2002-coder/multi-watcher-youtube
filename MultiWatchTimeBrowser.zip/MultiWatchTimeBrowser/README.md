# Multi Watch Time Browser — React Native Clone

A full React Native rebuild of **Multi Watch Time Browser v4.4.1**  
(original package: `androidbuilder.ab_fatirunnesa2020.Multi_Watch_Time`)

---

## ✨ What's New vs the Original

| Feature | Original APK | This Clone |
|---|---|---|
| Max windows | **8** | **20** |
| Ads | AdMob + Unity + Fyber + Facebook + IronSource | **Zero ads** |
| Source format | MIT App Inventor (no editable source) | **Full React Native project** |
| Per-window mute | ✗ | ✅ |
| Persistent URLs | ✅ | ✅ |
| Custom window count | 2 / 4 / 6 / 8 only | **Any value 1–20** |
| Edit & extend | ✗ | ✅ open-source |

---

## 🗂 Project Structure

```
MultiWatchTimeBrowser/
├── App.tsx                         # Entry point
├── package.json
├── tsconfig.json
├── babel.config.js
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml
└── src/
    ├── utils/
    │   └── constants.ts            # Colors, limits, config
    ├── hooks/
    │   └── useWindows.ts           # Window state management
    ├── components/
    │   └── BrowserWindowPane.tsx   # Single WebView pane with toolbar
    ├── screens/
    │   ├── BrowserScreen.tsx       # Main multi-window grid
    │   ├── SettingsScreen.tsx      # App settings
    │   └── AboutScreen.tsx         # App info
    └── navigation/
        └── RootNavigator.tsx       # Bottom tab navigator
```

---

## 🚀 Setup & Run

### Prerequisites
- Node.js 18+
- React Native CLI
- Android Studio (for Android) or Xcode (for iOS)

### Install
```bash
cd MultiWatchTimeBrowser
npm install

# iOS only
cd ios && pod install && cd ..
```

### Run
```bash
# Android
npx react-native run-android

# iOS
npx react-native run-ios

# Metro bundler only
npx react-native start
```

---

## 🪟 Window Layout System

The app supports a flexible grid of browser windows:

```
2 windows  → 1×2 grid
4 windows  → 2×2 grid
6 windows  → 2×3 grid
8 windows  → 2×4 grid   ← original max
10 windows → 2×5 grid
12 windows → 3×4 grid
16 windows → 4×4 grid
20 windows → 4×5 grid   ← new max
Custom     → any 1–20
```

To change `MAX_WINDOWS`, edit `src/utils/constants.ts`:
```ts
MAX_WINDOWS: 20,   // ← change this
```

---

## 🔧 Customisation

### Change default URL
```ts
// src/utils/constants.ts
DEFAULT_URL: 'https://www.youtube.com',
```

### Add window count options
```ts
WINDOW_OPTIONS: [2, 4, 6, 8, 10, 12, 16, 20],
```

### Change theme colours
```ts
COLORS: {
  primary: '#1a1a2e',
  accent: '#e94560',
  // ...
}
```

---

## 📦 Key Dependencies

| Package | Purpose |
|---|---|
| `react-native-webview` | Browser engine |
| `@react-navigation/bottom-tabs` | Tab navigation |
| `@react-native-async-storage/async-storage` | Persist URLs |
| `react-native-safe-area-context` | Safe area handling |
| `react-native-gesture-handler` | Gesture support |

---

## 📜 Original App Analysis

Reverse-engineered from APK using Python DEX string extraction.

**Screens found:** Screen1 (splash/chooser), Screen2 (main browser)  
**WebView instances:** WebViewer1 – WebViewer8 (hard-coded × 8)  
**Ad SDKs detected:**  
- AdMob (banner + interstitial + rewarded)  
- Unity Ads (full-screen + rewarded)  
- Fyber (interstitial)  
- Facebook Audience Network  
- IronSource / Max (AppLovin)  
- OneSignal (push notifications)  
**Firebase:** Realtime Database used for remote config  
**Built with:** MIT App Inventor / AndroidBuilder SDK  

All ad components have been omitted in this clone.
