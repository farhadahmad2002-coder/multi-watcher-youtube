@echo off
echo ============================================
echo  Multi Watch Time Browser - APK Builder
echo ============================================
echo.

where node >nul 2>nul || (echo [ERROR] Node.js not found. Install from https://nodejs.org & pause & exit /b 1)
where java >nul 2>nul || (echo [ERROR] Java JDK 17 not found. Install from https://adoptium.net & pause & exit /b 1)

echo [1/6] Installing npm packages...
call npm install
if %errorlevel% neq 0 (echo [ERROR] npm install failed & pause & exit /b 1)

echo.
echo [2/6] Copying Gradle wrapper jar...
if exist node_modules\@react-native-community\cli-platform-android\gradle\wrapper\gradle-wrapper.jar (
    copy node_modules\@react-native-community\cli-platform-android\gradle\wrapper\gradle-wrapper.jar android\gradle\wrapper\gradle-wrapper.jar
) else (
    echo Downloading gradle-wrapper.jar...
    powershell -Command "Invoke-WebRequest -Uri 'https://github.com/gradle/gradle/raw/v8.3.0/gradle/wrapper/gradle-wrapper.jar' -OutFile 'android\gradle\wrapper\gradle-wrapper.jar'"
)

echo.
echo [3/6] Generating debug keystore...
if not exist android\app\debug.keystore (
    keytool -genkeypair -v -storetype PKCS12 -keystore android\app\debug.keystore ^
        -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 ^
        -storepass android -keypass android -dname "CN=Android Debug,O=Android,C=US"
)

echo.
echo [4/6] Bundling JavaScript...
if not exist android\app\src\main\assets mkdir android\app\src\main\assets
node node_modules\react-native\cli.js bundle --platform android --dev false ^
    --entry-file index.js ^
    --bundle-output android\app\src\main\assets\index.android.bundle ^
    --assets-dest android\app\src\main\res
if %errorlevel% neq 0 (echo [ERROR] JS bundle failed & pause & exit /b 1)

echo.
echo [5/6] Building APK (takes 2-5 min first time)...
cd android
call gradlew.bat assembleRelease --no-daemon
if %errorlevel% neq 0 (echo [ERROR] Gradle build failed & cd .. & pause & exit /b 1)
cd ..

echo.
echo [6/6] Copying APK...
if not exist output mkdir output
copy android\app\build\outputs\apk\release\app-release.apk output\MultiWatchTimeBrowser.apk

echo.
echo ============================================
echo  APK ready at: output\MultiWatchTimeBrowser.apk
echo ============================================
echo Transfer to your phone and tap to install.
pause
