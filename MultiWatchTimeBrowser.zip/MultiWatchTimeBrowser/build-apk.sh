#!/bin/bash
set -e

echo "============================================"
echo " Multi Watch Time Browser - APK Builder"
echo "============================================"
echo

# Check Node
if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js not found. Install from https://nodejs.org"
    exit 1
fi

# Check Java
if ! command -v java &> /dev/null; then
    echo "[ERROR] Java not found. Install JDK 17 from https://adoptium.net"
    exit 1
fi

# Check ANDROID_HOME
if [ -z "$ANDROID_HOME" ]; then
    if [ -d "$HOME/Library/Android/sdk" ]; then
        export ANDROID_HOME="$HOME/Library/Android/sdk"
    elif [ -d "$HOME/Android/Sdk" ]; then
        export ANDROID_HOME="$HOME/Android/Sdk"
    else
        echo "[ERROR] ANDROID_HOME not set and Android SDK not found."
        echo "Install Android Studio then set: export ANDROID_HOME=~/Library/Android/sdk"
        exit 1
    fi
fi
echo "Using Android SDK: $ANDROID_HOME"

echo
echo "[1/6] Installing npm packages..."
npm install

echo
echo "[2/6] Copying Gradle wrapper jar..."
WRAPPER_SRC="node_modules/@react-native-community/cli-platform-android/gradle/wrapper/gradle-wrapper.jar"
WRAPPER_DST="android/gradle/wrapper/gradle-wrapper.jar"
if [ -f "$WRAPPER_SRC" ]; then
    cp "$WRAPPER_SRC" "$WRAPPER_DST"
    echo "  Copied from node_modules"
elif [ -f "node_modules/react-native/android/gradle/wrapper/gradle-wrapper.jar" ]; then
    cp "node_modules/react-native/android/gradle/wrapper/gradle-wrapper.jar" "$WRAPPER_DST"
    echo "  Copied from react-native"
else
    echo "  Downloading gradle-wrapper.jar..."
    curl -L -o "$WRAPPER_DST" \
      "https://github.com/gradle/gradle/raw/v8.3.0/gradle/wrapper/gradle-wrapper.jar" \
      || { echo "[ERROR] Could not get gradle-wrapper.jar"; exit 1; }
fi

echo
echo "[3/6] Generating debug keystore..."
if [ ! -f android/app/debug.keystore ]; then
    keytool -genkeypair -v -storetype PKCS12 \
        -keystore android/app/debug.keystore \
        -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 \
        -storepass android -keypass android \
        -dname "CN=Android Debug,O=Android,C=US"
    echo "  Keystore created"
else
    echo "  Keystore already exists"
fi

echo
echo "[4/6] Bundling JavaScript..."
mkdir -p android/app/src/main/assets
node node_modules/react-native/cli.js bundle \
    --platform android \
    --dev false \
    --entry-file index.js \
    --bundle-output android/app/src/main/assets/index.android.bundle \
    --assets-dest android/app/src/main/res

echo
echo "[5/6] Building APK (this takes 2-5 minutes first time)..."
cd android
chmod +x gradlew
./gradlew assembleRelease --no-daemon
cd ..

echo
echo "[6/6] Done!"
mkdir -p output
cp android/app/build/outputs/apk/release/app-release.apk output/MultiWatchTimeBrowser.apk

echo
echo "============================================"
echo " APK ready at: output/MultiWatchTimeBrowser.apk"
echo "============================================"
echo "Transfer to your Android phone and tap to install."
echo "(Enable 'Install unknown apps' in Settings if prompted)"
