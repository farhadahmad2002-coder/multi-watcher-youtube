import { useState, useCallback, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { APP_CONFIG } from '../utils/constants';

export interface BrowserWindow {
  id: string;
  url: string;
  title: string;
  isLoading: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
  progress: number;
  isMuted: boolean;
  favicon?: string;
}

const createWindow = (url?: string): BrowserWindow => ({
  id: `win_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
  url: url ?? APP_CONFIG.DEFAULT_URL,
  title: 'New Window',
  isLoading: false,
  canGoBack: false,
  canGoForward: false,
  progress: 0,
  isMuted: false,
});

const STORAGE_KEY = '@mwtb_windows';

export const useWindows = () => {
  const [windows, setWindows] = useState<BrowserWindow[]>(() =>
    Array.from({ length: APP_CONFIG.DEFAULT_WINDOWS }, () => createWindow()),
  );
  const [windowCount, setWindowCount] = useState(APP_CONFIG.DEFAULT_WINDOWS);
  const [isLoading, setIsLoading] = useState(false);
  const webViewRefs = useRef<Record<string, any>>({});

  // ── Persist URLs ────────────────────────────────────────────────────────────
  const saveUrls = useCallback(async (wins: BrowserWindow[]) => {
    try {
      const urls = wins.map(w => w.url);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(urls));
    } catch (_) {}
  }, []);

  const loadSavedUrls = useCallback(async () => {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (raw) {
        const urls: string[] = JSON.parse(raw);
        setWindows(urls.map(u => createWindow(u)));
        setWindowCount(urls.length);
      }
    } catch (_) {}
  }, []);

  // ── Window management ───────────────────────────────────────────────────────
  const setWindowLayout = useCallback(
    (count: number) => {
      const clamped = Math.min(count, APP_CONFIG.MAX_WINDOWS);
      setWindowCount(clamped);
      setWindows(prev => {
        if (prev.length === clamped) return prev;
        if (prev.length < clamped) {
          const added = Array.from({ length: clamped - prev.length }, () =>
            createWindow(),
          );
          const next = [...prev, ...added];
          saveUrls(next);
          return next;
        }
        const next = prev.slice(0, clamped);
        saveUrls(next);
        return next;
      });
    },
    [saveUrls],
  );

  const addWindow = useCallback(() => {
    setWindows(prev => {
      if (prev.length >= APP_CONFIG.MAX_WINDOWS) return prev;
      const next = [...prev, createWindow()];
      setWindowCount(next.length);
      saveUrls(next);
      return next;
    });
  }, [saveUrls]);

  const removeWindow = useCallback(
    (id: string) => {
      setWindows(prev => {
        if (prev.length <= 1) return prev;
        const next = prev.filter(w => w.id !== id);
        setWindowCount(next.length);
        saveUrls(next);
        delete webViewRefs.current[id];
        return next;
      });
    },
    [saveUrls],
  );

  const updateWindow = useCallback(
    (id: string, patch: Partial<BrowserWindow>) => {
      setWindows(prev =>
        prev.map(w => (w.id === id ? { ...w, ...patch } : w)),
      );
    },
    [],
  );

  const navigateWindow = useCallback(
    (id: string, url: string) => {
      const normalised = url.startsWith('http') ? url : `https://${url}`;
      updateWindow(id, { url: normalised });
      saveUrls(
        windows.map(w => (w.id === id ? { ...w, url: normalised } : w)),
      );
    },
    [windows, updateWindow, saveUrls],
  );

  const reloadWindow = useCallback((id: string) => {
    const ref = webViewRefs.current[id];
    ref?.reload();
  }, []);

  const goBack = useCallback((id: string) => {
    webViewRefs.current[id]?.goBack();
  }, []);

  const goForward = useCallback((id: string) => {
    webViewRefs.current[id]?.goForward();
  }, []);

  const setUrl = useCallback(
    (id: string, url: string) => {
      navigateWindow(id, url);
    },
    [navigateWindow],
  );

  const toggleMute = useCallback(
    (id: string) => {
      setWindows(prev =>
        prev.map(w =>
          w.id === id ? { ...w, isMuted: !w.isMuted } : w,
        ),
      );
    },
    [],
  );

  const setWebViewRef = useCallback((id: string, ref: any) => {
    if (ref) {
      webViewRefs.current[id] = ref;
    }
  }, []);

  return {
    windows,
    windowCount,
    isLoading,
    addWindow,
    removeWindow,
    updateWindow,
    navigateWindow,
    setWindowLayout,
    reloadWindow,
    goBack,
      goForward,
    setUrl,
    toggleMute,
    setWebViewRef,
    loadSavedUrls,
  };
};
