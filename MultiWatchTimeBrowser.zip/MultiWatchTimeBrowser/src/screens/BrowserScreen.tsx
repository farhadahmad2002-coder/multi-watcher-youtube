import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Modal,
  ScrollView,
  StyleSheet,
  Dimensions,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import BrowserWindowPane from '../components/BrowserWindowPane';
import { useWindows } from '../hooks/useWindows';
import { APP_CONFIG, WINDOW_GRID_LAYOUTS } from '../utils/constants';

const { COLORS, WINDOW_OPTIONS, MAX_WINDOWS } = APP_CONFIG;
const SCREEN = Dimensions.get('window');

const BrowserScreen: React.FC = () => {
  const {
    windows,
    windowCount,
    addWindow,
    removeWindow,
    updateWindow,
    navigateWindow,
    setWindowLayout,
    setWebViewRef,
    loadSavedUrls,
  } = useWindows();

  const [showLayoutPicker, setShowLayoutPicker] = useState(false);
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>(
    SCREEN.height > SCREEN.width ? 'portrait' : 'landscape',
  );

  useEffect(() => {
    loadSavedUrls();
    const sub = Dimensions.addEventListener('change', ({ window }) => {
      setOrientation(window.height > window.width ? 'portrait' : 'landscape');
    });
    return () => sub?.remove?.();
  }, []);

  // ── Grid layout calculation ────────────────────────────────────────────────
  const layout = WINDOW_GRID_LAYOUTS[windowCount] ??
    (windowCount <= 4
      ? { rows: 2, cols: 2 }
      : windowCount <= 9
      ? { rows: 3, cols: 3 }
      : { rows: 4, cols: Math.ceil(windowCount / 4) });

  const rows: typeof windows[] = [];
  for (let r = 0; r < layout.rows; r++) {
    rows.push(windows.slice(r * layout.cols, (r + 1) * layout.cols));
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>📺 Multi Watch Time</Text>
        <View style={styles.headerRight}>
          {/* Window count badge */}
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{windowCount}</Text>
          </View>

          {/* Choose Layout */}
          <TouchableOpacity
            style={styles.headerBtn}
            onPress={() => setShowLayoutPicker(true)}
          >
            <Text style={styles.headerBtnText}>⊞ Layout</Text>
          </TouchableOpacity>

          {/* Add Window */}
          {windowCount < MAX_WINDOWS && (
            <TouchableOpacity style={styles.headerBtn} onPress={addWindow}>
              <Text style={styles.headerBtnText}>＋</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* ── Browser Grid ───────────────────────────────────────────────────── */}
      <View style={styles.grid}>
        {rows.map((rowWindows, rIdx) => (
          <View key={rIdx} style={styles.row}>
            {rowWindows.map(win => (
              <BrowserWindowPane
                key={win.id}
                window={win}
                onUpdate={updateWindow}
                onNavigate={navigateWindow}
                onRemove={windowCount > 1 ? removeWindow : undefined}
                onRef={setWebViewRef}
                showControls
                totalWindows={windowCount}
              />
            ))}
          </View>
        ))}
      </View>

      {/* ── Layout Picker Modal ────────────────────────────────────────────── */}
      <Modal
        visible={showLayoutPicker}
        transparent
        animationType="fade"
        onRequestClose={() => setShowLayoutPicker(false)}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setShowLayoutPicker(false)}
        >
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Choose Windows</Text>
            <Text style={styles.modalSubtitle}>
              Select how many browser windows to show
            </Text>

            <ScrollView contentContainerStyle={styles.gridOptions}>
              {WINDOW_OPTIONS.map(count => (
                <TouchableOpacity
                  key={count}
                  style={[
                    styles.optionBtn,
                    windowCount === count && styles.optionBtnActive,
                  ]}
                  onPress={() => {
                    setWindowLayout(count);
                    setShowLayoutPicker(false);
                  }}
                >
                  <Text
                    style={[
                      styles.optionText,
                      windowCount === count && styles.optionTextActive,
                    ]}
                  >
                    {count}
                  </Text>
                  <Text style={styles.optionLabel}>
                    {count} {count === 1 ? 'Window' : 'Windows'}
                  </Text>
                  {count > 8 && (
                    <Text style={styles.newBadge}>NEW</Text>
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>

            {/* Custom count */}
            <View style={styles.customRow}>
              <Text style={styles.customLabel}>Custom (up to {MAX_WINDOWS}):</Text>
              <View style={styles.stepper}>
                <TouchableOpacity
                  style={styles.stepBtn}
                  onPress={() => windowCount > 1 && setWindowLayout(windowCount - 1)}
                >
                  <Text style={styles.stepBtnText}>−</Text>
                </TouchableOpacity>
                <Text style={styles.stepCount}>{windowCount}</Text>
                <TouchableOpacity
                  style={styles.stepBtn}
                  onPress={() => windowCount < MAX_WINDOWS && setWindowLayout(windowCount + 1)}
                >
                  <Text style={styles.stepBtnText}>+</Text>
                </TouchableOpacity>
              </View>
            </View>

            <TouchableOpacity
              style={styles.modalCloseBtn}
              onPress={() => setShowLayoutPicker(false)}
            >
              <Text style={styles.modalCloseBtnText}>Apply</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
};

export default BrowserScreen;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.primary,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primaryDark,
    paddingHorizontal: 12,
    paddingVertical: 8,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  headerTitle: {
    color: COLORS.text,
    fontSize: 16,
    fontWeight: 'bold',
    flex: 1,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  badge: {
    backgroundColor: COLORS.accent,
    borderRadius: 12,
    minWidth: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 6,
  },
  badgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  headerBtn: {
    backgroundColor: COLORS.background,
    borderRadius: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  headerBtnText: {
    color: COLORS.text,
    fontSize: 12,
    fontWeight: '600',
  },
  grid: {
    flex: 1,
  },
  row: {
    flex: 1,
    flexDirection: 'row',
  },
  // ── Modal ─────────────────────────────────────────────────────────────────
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 16,
    padding: 20,
    width: '90%',
    maxHeight: '80%',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  modalTitle: {
    color: COLORS.text,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 4,
  },
  modalSubtitle: {
    color: COLORS.textSecondary,
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 16,
  },
  gridOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 10,
    paddingBottom: 8,
  },
  optionBtn: {
    width: 80,
    height: 80,
    backgroundColor: COLORS.primaryDark,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: COLORS.border,
    position: 'relative',
  },
  optionBtnActive: {
    borderColor: COLORS.accent,
    backgroundColor: COLORS.background,
  },
  optionText: {
    color: COLORS.text,
    fontSize: 28,
    fontWeight: 'bold',
  },
  optionTextActive: {
    color: COLORS.accent,
  },
  optionLabel: {
    color: COLORS.textSecondary,
    fontSize: 10,
    marginTop: 2,
  },
  newBadge: {
    position: 'absolute',
    top: 4,
    right: 4,
    backgroundColor: COLORS.success,
    color: '#fff',
    fontSize: 8,
    fontWeight: 'bold',
    paddingHorizontal: 4,
    paddingVertical: 1,
    borderRadius: 4,
    overflow: 'hidden',
  },
  customRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  customLabel: {
    color: COLORS.textSecondary,
    fontSize: 13,
  },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  stepBtn: {
    backgroundColor: COLORS.background,
    width: 36,
    height: 36,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  stepBtnText: {
    color: COLORS.text,
    fontSize: 20,
    fontWeight: 'bold',
  },
  stepCount: {
    color: COLORS.text,
    fontSize: 18,
    fontWeight: 'bold',
    minWidth: 30,
    textAlign: 'center',
  },
  modalCloseBtn: {
    backgroundColor: COLORS.accent,
    borderRadius: 10,
    padding: 14,
    marginTop: 16,
    alignItems: 'center',
  },
  modalCloseBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
