import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  Switch, StyleSheet, Linking, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { APP_CONFIG } from '../utils/constants';

const { COLORS } = APP_CONFIG;

const Row: React.FC<{
  label: string; sub?: string;
  right?: React.ReactNode; onPress?: () => void;
}> = ({ label, sub, right, onPress }) => (
  <TouchableOpacity
    style={styles.row} onPress={onPress} disabled={!onPress}
    activeOpacity={onPress ? 0.7 : 1}
  >
    <View style={{ flex: 1 }}>
      <Text style={styles.rowLabel}>{label}</Text>
      {sub ? <Text style={styles.rowSub}>{sub}</Text> : null}
    </View>
    {right}
  </TouchableOpacity>
);

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <View style={styles.section}>
    <Text style={styles.sectionTitle}>{title}</Text>
    <View style={styles.sectionCard}>{children}</View>
  </View>
);

const SettingsScreen: React.FC = () => {
  const [jsEnabled, setJsEnabled] = useState(true);
  const [saveHistory, setSaveHistory] = useState(true);
  const [autoplay, setAutoplay] = useState(true);
  const [darkMode, setDarkMode] = useState(true);

  const clearStorage = () => {
    Alert.alert('Clear All Data', 'This will clear saved URLs and history.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Clear', style: 'destructive',
        onPress: async () => {
          await AsyncStorage.clear();
          Alert.alert('Done', 'All data cleared.');
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>⚙️ Settings</Text>
      </View>
      <ScrollView contentContainerStyle={styles.scroll}>

        <Section title="BROWSER">
          <Row label="JavaScript" sub="Enable JS on all pages"
            right={<Switch value={jsEnabled} onValueChange={setJsEnabled}
              trackColor={{ false: COLORS.border, true: COLORS.accent }}
              thumbColor="#fff" />}
          />
          <Row label="Save URLs" sub="Remember last visited URLs"
            right={<Switch value={saveHistory} onValueChange={setSaveHistory}
              trackColor={{ false: COLORS.border, true: COLORS.accent }}
              thumbColor="#fff" />}
          />
          <Row label="Autoplay Media" sub="Allow videos to autoplay"
            right={<Switch value={autoplay} onValueChange={setAutoplay}
              trackColor={{ false: COLORS.border, true: COLORS.accent }}
              thumbColor="#fff" />}
          />
        </Section>

        <Section title="APPEARANCE">
          <Row label="Dark Mode" sub="Use dark theme (recommended)"
            right={<Switch value={darkMode} onValueChange={setDarkMode}
              trackColor={{ false: COLORS.border, true: COLORS.accent }}
              thumbColor="#fff" />}
          />
        </Section>

        <Section title="WINDOWS">
          <Row label="Max Windows" sub={`Up to ${APP_CONFIG.MAX_WINDOWS} simultaneous windows`}
            right={<Text style={styles.valueText}>{APP_CONFIG.MAX_WINDOWS}</Text>}
          />
          <Row label="Default Layout" sub="Windows on app start"
            right={<Text style={styles.valueText}>{APP_CONFIG.DEFAULT_WINDOWS}</Text>}
          />
        </Section>

        <Section title="DATA">
          <Row label="Clear Saved Data" sub="Remove saved URLs and history"
            onPress={clearStorage}
            right={<Text style={styles.danger}>Clear</Text>}
          />
        </Section>

        <Section title="ABOUT">
          <Row label="Version" right={<Text style={styles.valueText}>1.0.0</Text>} />
          <Row label="Original App" sub="Multi Watch Time Browser 4.4.1"
            right={<Text style={styles.valueText}>Clone</Text>}
          />
          <Row label="Privacy Policy"
            onPress={() => Linking.openURL('https://appscreatorbd.blogspot.com/p/multi-watch-time-browser-app-privacy.html')}
            right={<Text style={styles.link}>Open ›</Text>}
          />
          <Row label="Play Store"
            onPress={() => Linking.openURL('https://play.google.com/store/apps/details?id=com.multi_watch_time.bd')}
            right={<Text style={styles.link}>Open ›</Text>}
          />
        </Section>

      </ScrollView>
    </SafeAreaView>
  );
};

export default SettingsScreen;

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.primary },
  header: {
    backgroundColor: COLORS.primaryDark,
    paddingHorizontal: 16, paddingVertical: 12,
    elevation: 4,
  },
  headerTitle: { color: COLORS.text, fontSize: 18, fontWeight: 'bold' },
  scroll: { padding: 16, paddingBottom: 40 },
  section: { marginBottom: 20 },
  sectionTitle: {
    color: COLORS.textSecondary, fontSize: 11,
    fontWeight: '700', letterSpacing: 1,
    marginBottom: 6, paddingLeft: 4,
  },
  sectionCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 12, overflow: 'hidden',
    borderWidth: 1, borderColor: COLORS.border,
  },
  row: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  rowLabel: { color: COLORS.text, fontSize: 15 },
  rowSub: { color: COLORS.textSecondary, fontSize: 12, marginTop: 2 },
  valueText: { color: COLORS.accent, fontSize: 14, fontWeight: '600' },
  danger: { color: COLORS.error, fontSize: 14, fontWeight: '600' },
  link: { color: COLORS.accent, fontSize: 14 },
});
