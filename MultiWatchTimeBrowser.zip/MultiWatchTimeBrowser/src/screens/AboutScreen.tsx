import React from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { APP_CONFIG } from '../utils/constants';

const { COLORS } = APP_CONFIG;

const AboutScreen: React.FC = () => (
  <SafeAreaView style={styles.safe} edges={['top']}>
    <View style={styles.header}>
      <Text style={styles.headerTitle}>ℹ️ About</Text>
    </View>
    <ScrollView contentContainerStyle={styles.scroll}>

      {/* Hero */}
      <View style={styles.hero}>
        <View style={styles.iconBox}>
          <Text style={styles.iconEmoji}>📺</Text>
        </View>
        <Text style={styles.appName}>Multi Watch Time Browser</Text>
        <Text style={styles.version}>Version 1.0.0  •  React Native Clone</Text>
        <Text style={styles.tagline}>
          Watch multiple YouTube videos simultaneously to boost your watch time!
        </Text>
      </View>

      {/* Feature cards */}
      {[
        { icon: '🪟', title: `Up to ${APP_CONFIG.MAX_WINDOWS} Windows`, body: 'Open up to 20 simultaneous browser windows — more than 2× the original limit of 8.' },
        { icon: '🚫', title: 'Zero Ads', body: 'This clone removes all AdMob, Unity, Fyber, and OneSignal ad SDKs from the original.' },
        { icon: '🔇', title: 'Per-Window Mute', body: 'Mute individual windows to keep audio on just the videos you want.' },
        { icon: '💾', title: 'Persistent URLs', body: 'Your last-visited URLs are saved and restored between sessions.' },
        { icon: '🔍', title: 'Smart Search', body: 'Type a URL or search query — the app intelligently routes to Google Search when needed.' },
        { icon: '⚡', title: 'Full WebView', body: 'Uses the native Android/iOS WebView with JavaScript, autoplay, fullscreen video, and geolocation support.' },
      ].map(f => (
        <View key={f.title} style={styles.card}>
          <Text style={styles.cardIcon}>{f.icon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardTitle}>{f.title}</Text>
            <Text style={styles.cardBody}>{f.body}</Text>
          </View>
        </View>
      ))}

      {/* Tech stack */}
      <View style={styles.techSection}>
        <Text style={styles.techTitle}>Built With</Text>
        {['React Native 0.73', 'react-native-webview', '@react-navigation/native', 'TypeScript', 'AsyncStorage'].map(t => (
          <Text key={t} style={styles.techItem}>• {t}</Text>
        ))}
      </View>

      {/* Original app info */}
      <View style={styles.originalSection}>
        <Text style={styles.originalTitle}>Original App</Text>
        <Text style={styles.originalBody}>
          Package: androidbuilder.ab_fatirunnesa2020.Multi_Watch_Time{'\n'}
          Built with: MIT App Inventor / AndroidBuilder{'\n'}
          Version: 4.4.1{'\n'}
          Max windows (original): 8{'\n'}
          Ad SDKs: AdMob, Unity Ads, Fyber, Facebook, IronSource
        </Text>
      </View>

      <TouchableOpacity
        style={styles.privacyBtn}
        onPress={() => Linking.openURL('https://appscreatorbd.blogspot.com/p/multi-watch-time-browser-app-privacy.html')}
      >
        <Text style={styles.privacyBtnText}>Privacy Policy</Text>
      </TouchableOpacity>

    </ScrollView>
  </SafeAreaView>
);

export default AboutScreen;

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.primary },
  header: {
    backgroundColor: COLORS.primaryDark,
    paddingHorizontal: 16, paddingVertical: 12, elevation: 4,
  },
  headerTitle: { color: COLORS.text, fontSize: 18, fontWeight: 'bold' },
  scroll: { padding: 16, paddingBottom: 40 },
  hero: {
    alignItems: 'center', marginBottom: 24, paddingVertical: 20,
    backgroundColor: COLORS.surface, borderRadius: 16,
    borderWidth: 1, borderColor: COLORS.border,
  },
  iconBox: {
    width: 80, height: 80, borderRadius: 20,
    backgroundColor: COLORS.background,
    justifyContent: 'center', alignItems: 'center',
    marginBottom: 12, borderWidth: 2, borderColor: COLORS.accent,
  },
  iconEmoji: { fontSize: 40 },
  appName: { color: COLORS.text, fontSize: 20, fontWeight: 'bold', marginBottom: 4 },
  version: { color: COLORS.textSecondary, fontSize: 12, marginBottom: 10 },
  tagline: {
    color: COLORS.textSecondary, fontSize: 13,
    textAlign: 'center', paddingHorizontal: 20, lineHeight: 20,
  },
  card: {
    flexDirection: 'row', alignItems: 'flex-start',
    backgroundColor: COLORS.surface, borderRadius: 12, padding: 14,
    marginBottom: 10, borderWidth: 1, borderColor: COLORS.border, gap: 12,
  },
  cardIcon: { fontSize: 24, marginTop: 2 },
  cardTitle: { color: COLORS.text, fontSize: 15, fontWeight: '700', marginBottom: 4 },
  cardBody: { color: COLORS.textSecondary, fontSize: 13, lineHeight: 18 },
  techSection: {
    backgroundColor: COLORS.surface, borderRadius: 12,
    padding: 14, marginBottom: 12, borderWidth: 1, borderColor: COLORS.border,
  },
  techTitle: { color: COLORS.accent, fontSize: 13, fontWeight: '700', marginBottom: 8 },
  techItem: { color: COLORS.textSecondary, fontSize: 13, marginBottom: 4 },
  originalSection: {
    backgroundColor: COLORS.primaryDark, borderRadius: 12,
    padding: 14, marginBottom: 16, borderWidth: 1, borderColor: COLORS.border,
  },
  originalTitle: { color: COLORS.textSecondary, fontSize: 11, fontWeight: '700', letterSpacing: 1, marginBottom: 8 },
  originalBody: { color: COLORS.textSecondary, fontSize: 12, lineHeight: 20, fontFamily: 'monospace' },
  privacyBtn: {
    backgroundColor: COLORS.background, borderRadius: 10, padding: 14,
    alignItems: 'center', borderWidth: 1, borderColor: COLORS.border,
  },
  privacyBtnText: { color: COLORS.accent, fontSize: 14, fontWeight: '600' },
});
