import React from 'react';
import { Text } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import BrowserScreen from '../screens/BrowserScreen';
import SettingsScreen from '../screens/SettingsScreen';
import AboutScreen from '../screens/AboutScreen';
import { APP_CONFIG } from '../utils/constants';

const Tab = createBottomTabNavigator();
const { COLORS } = APP_CONFIG;

const icon = (emoji: string) => () => <Text style={{ fontSize: 20 }}>{emoji}</Text>;

const RootNavigator: React.FC = () => (
  <Tab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarStyle: {
        backgroundColor: COLORS.tabBar,
        borderTopColor: COLORS.border,
        borderTopWidth: 1,
        height: 56,
      },
      tabBarActiveTintColor: COLORS.tabBarActive,
      tabBarInactiveTintColor: COLORS.textSecondary,
      tabBarLabelStyle: { fontSize: 11, marginBottom: 4 },
    }}
  >
    <Tab.Screen
      name="Browser"
      component={BrowserScreen}
      options={{ tabBarIcon: icon('🌐'), tabBarLabel: 'Browser' }}
    />
    <Tab.Screen
      name="Settings"
      component={SettingsScreen}
      options={{ tabBarIcon: icon('⚙️'), tabBarLabel: 'Settings' }}
    />
    <Tab.Screen
      name="About"
      component={AboutScreen}
      options={{ tabBarIcon: icon('ℹ️'), tabBarLabel: 'About' }}
    />
  </Tab.Navigator>
);

export default RootNavigator;
