// App Constants — Multi Watch Time Browser Clone
// Original app: androidbuilder.ab_fatirunnesa2020.Multi_Watch_Time
// Original max windows: 8  →  We support up to 20

export const APP_CONFIG = {
  APP_NAME: 'Multi Watch Time Browser',
  APP_VERSION: '1.0.0',
  PACKAGE_NAME: 'com.multiwatchtimebrowser',

  // ─── Window / Tab limits ───────────────────────────────
  MAX_WINDOWS: 20,          // Original was 8 — now unlimited (soft cap 20)
  DEFAULT_WINDOWS: 2,

  // ─── Window layout options (mirroring the original) ────
  WINDOW_OPTIONS: [2, 4, 6, 8, 10, 12, 16, 20],

  // ─── Default URLs ──────────────────────────────────────
  DEFAULT_URL: 'https://www.youtube.com',
  HOME_URL: 'https://www.youtube.com',
  FIREBASE_URL: 'https://multi-watch-time-default-rtdb.firebaseio.com/',

  // ─── Theme colours ─────────────────────────────────────
  COLORS: {
    primary: '#1a1a2e',
    primaryDark: '#16213e',
    accent: '#e94560',
    accentLight: '#ff6b6b',
    background: '#0f3460',
    surface: '#1a1a2e',
    text: '#ffffff',
    textSecondary: '#b0b0b0',
    border: '#333355',
    success: '#4caf50',
    warning: '#ff9800',
    error: '#f44336',
    webViewBg: '#000000',
    tabBar: '#0d0d1a',
    tabBarActive: '#e94560',
  },

  // ─── YouTube watch-time helpers ────────────────────────
  WATCH_TIME_TIPS: [
    'Open multiple YouTube videos simultaneously to boost watch time!',
    'Use 2-20 windows to watch different channels at once.',
    'Enable autoplay on each tab for maximum watch time.',
    'Mute unwanted videos to focus on your main content.',
  ],
};

export const WINDOW_GRID_LAYOUTS: Record<number, { rows: number; cols: number }> = {
  1:  { rows: 1, cols: 1 },
  2:  { rows: 1, cols: 2 },
  4:  { rows: 2, cols: 2 },
  6:  { rows: 2, cols: 3 },
  8:  { rows: 2, cols: 4 },
  9:  { rows: 3, cols: 3 },
  10: { rows: 2, cols: 5 },
  12: { rows: 3, cols: 4 },
  16: { rows: 4, cols: 4 },
  20: { rows: 4, cols: 5 },
};
