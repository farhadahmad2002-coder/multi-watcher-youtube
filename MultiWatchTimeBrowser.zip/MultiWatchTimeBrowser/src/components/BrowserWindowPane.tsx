import React, { useRef, useState, forwardRef, useImperativeHandle } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { WebView } from 'react-native-webview';
import { APP_CONFIG } from '../utils/constants';
import type { BrowserWindow as BrowserWindowType } from '../hooks/useWindows';

interface Props {
  window: BrowserWindowType;
  onUpdate: (id: string, patch: Partial<BrowserWindowType>) => void;
  onNavigate: (id: string, url: string) => void;
  onRemove?: (id: string) => void;
  onRef: (id: string, ref: any) => void;
  showControls?: boolean;
  totalWindows: number;
}

const { COLORS } = APP_CONFIG;

const BrowserWindowPane: React.FC<Props> = ({
  window: win,
  onUpdate,
  onNavigate,
  onRemove,
  onRef,
  showControls = true,
  totalWindows,
}) => {
  const webViewRef = useRef<any>(null);
  const [urlInput, setUrlInput] = useState(win.url);
  const [editingUrl, setEditingUrl] = useState(false);

  const handleNavigate = () => {
    let url = urlInput.trim();
    if (!url) return;

    // Smart URL / search detection
    if (!url.includes('.') || url.includes(' ')) {
      url = `https://www.google.com/search?q=${encodeURIComponent(url)}`;
    } else if (!url.startsWith('http')) {
      url = `https://${url}`;
    }

    onNavigate(win.id, url);
    setEditingUrl(false);
  };

  const isSmall = totalWindows > 4;
  const isVerySmall = totalWindows > 8;

  return (
    <View style={[styles.container, isSmall && styles.containerSmall]}>
      {/* ── URL Bar ──────────────────────────────────────────────────────── */}
      {showControls && (
        <View style={[styles.toolbar, isSmall && styles.toolbarSmall]}>
          {/* Back */}
          <TouchableOpacity
            style={styles.navBtn}
            onPress={() => webViewRef.current?.goBack()}
            disabled={!win.canGoBack}
          >
            <Text style={[styles.navBtnText, !win.canGoBack && styles.disabled]}>‹</Text>
          </TouchableOpacity>

          {/* Forward */}
          <TouchableOpacity
            style={styles.navBtn}
            onPress={() => webViewRef.current?.goForward()}
            disabled={!win.canGoForward}
          >
            <Text style={[styles.navBtnText, !win.canGoForward && styles.disabled]}>›</Text>
          </TouchableOpacity>

          {/* URL Input */}
          <TextInput
            style={[styles.urlInput, isSmall && styles.urlInputSmall]}
            value={editingUrl ? urlInput : win.url}
            onChangeText={setUrlInput}
            onFocus={() => {
              setEditingUrl(true);
              setUrlInput(win.url);
            }}
            onBlur={() => setEditingUrl(false)}
            onSubmitEditing={handleNavigate}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="url"
            returnKeyType="go"
            placeholder="Search or enter URL..."
            placeholderTextColor={COLORS.textSecondary}
            selectTextOnFocus
          />

          {/* Reload */}
          <TouchableOpacity
            style={styles.navBtn}
            onPress={() => {
              if (win.isLoading) {
                webViewRef.current?.stopLoading();
              } else {
                webViewRef.current?.reload();
              }
            }}
          >
            <Text style={styles.navBtnText}>{win.isLoading ? '✕' : '↻'}</Text>
          </TouchableOpacity>

          {/* Mute */}
          {!isVerySmall && (
            <TouchableOpacity
              style={styles.navBtn}
              onPress={() => onUpdate(win.id, { isMuted: !win.isMuted })}
            >
              <Text style={styles.navBtnText}>{win.isMuted ? '🔇' : '🔊'}</Text>
            </TouchableOpacity>
          )}

          {/* Close (only when multiple windows) */}
          {onRemove && totalWindows > 1 && (
            <TouchableOpacity
              style={[styles.navBtn, styles.closeBtn]}
              onPress={() => onRemove(win.id)}
            >
              <Text style={styles.closeBtnText}>✕</Text>
            </TouchableOpacity>
          )}
        </View>
      )}

      {/* ── Progress bar ─────────────────────────────────────────────────── */}
      {win.isLoading && (
        <View style={styles.progressBar}>
          <View
            style={[styles.progressFill, { width: `${win.progress * 100}%` as any }]}
          />
        </View>
      )}

      {/* ── WebView ──────────────────────────────────────────────────────── */}
      <WebView
        ref={ref => {
          webViewRef.current = ref;
          onRef(win.id, ref);
        }}
        source={{ uri: win.url }}
        style={styles.webView}
        onLoadStart={() => onUpdate(win.id, { isLoading: true })}
        onLoadProgress={({ nativeEvent }) =>
          onUpdate(win.id, { progress: nativeEvent.progress })
        }
        onLoadEnd={() => onUpdate(win.id, { isLoading: false, progress: 1 })}
        onNavigationStateChange={state => {
          onUpdate(win.id, {
            url: state.url,
            title: state.title || 'Untitled',
            canGoBack: state.canGoBack,
            canGoForward: state.canGoForward,
          });
          if (!editingUrl) setUrlInput(state.url);
        }}
        mediaPlaybackRequiresUserAction={false}
        allowsInlineMediaPlayback
        javaScriptEnabled
        domStorageEnabled
        allowsFullscreenVideo
        // Inject mute script when isMuted changes
        injectedJavaScript={
          win.isMuted
            ? `document.querySelectorAll('video,audio').forEach(el=>el.muted=true); true;`
            : `document.querySelectorAll('video,audio').forEach(el=>el.muted=false); true;`
        }
        userAgent={
          'Mozilla/5.0 (Linux; Android 13; Pixel 7) ' +
          'AppleWebKit/537.36 (KHTML, like Gecko) ' +
          'Chrome/120.0.0.0 Mobile Safari/537.36'
        }
        onError={() => onUpdate(win.id, { isLoading: false })}
        renderError={() => (
          <View style={styles.errorView}>
            <Text style={styles.errorText}>⚠️ Failed to load page</Text>
            <TouchableOpacity onPress={() => webViewRef.current?.reload()}>
              <Text style={styles.retryText}>Tap to retry</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
};

export default BrowserWindowPane;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  containerSmall: {
    borderWidth: 0.5,
  },
  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primaryDark,
    paddingHorizontal: 4,
    paddingVertical: 4,
    height: 40,
  },
  toolbarSmall: {
    height: 28,
    paddingHorizontal: 2,
    paddingVertical: 2,
  },
  navBtn: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  navBtnText: {
    color: COLORS.text,
    fontSize: 18,
    fontWeight: 'bold',
  },
  disabled: {
    opacity: 0.35,
  },
  urlInput: {
    flex: 1,
    backgroundColor: COLORS.primary,
    color: COLORS.text,
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
    fontSize: 11,
    marginHorizontal: 3,
  },
  urlInputSmall: {
    fontSize: 9,
    paddingHorizontal: 4,
    paddingVertical: 1,
    borderRadius: 3,
  },
  closeBtn: {
    backgroundColor: COLORS.error,
    borderRadius: 4,
    marginLeft: 2,
  },
  closeBtnText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: 'bold',
  },
  progressBar: {
    height: 2,
    backgroundColor: COLORS.border,
  },
  progressFill: {
    height: 2,
    backgroundColor: COLORS.accent,
  },
  webView: {
    flex: 1,
    backgroundColor: COLORS.webViewBg,
  },
  errorView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
  },
  errorText: {
    color: COLORS.textSecondary,
    fontSize: 16,
    marginBottom: 12,
  },
  retryText: {
    color: COLORS.accent,
    fontSize: 14,
    textDecorationLine: 'underline',
  },
});
